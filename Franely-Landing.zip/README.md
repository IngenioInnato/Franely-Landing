# Franely Beauty Lashes

Landing page para realiar ventas de pestañas magnéticas. Captando datos por un formulario validado y enviando datos obtenidos a email específico y añadido datos en google sheet.